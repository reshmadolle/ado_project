﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project.Ado.Model
{
    class DataLogic
    {
        private string constr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        //private string connectionString;
        //private string message;
        //private Data ob;

        public DataSet getAllData()
        {
            DataSet ds = new DataSet();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from sys.tables ; select * from EMPLOYEE ; Select * from depatement";

            try
            {
                conn.Open();
                SqlDataAdapter daAdapter = new SqlDataAdapter(sql, conn);
                daAdapter.Fill(ds);
            }
            catch (Exception)
            {
                MessageBox.Show("Couldnt connect to db");
            }
            finally
            {
                conn.Close();
            }

            return ds;
        }
        //searching with id in from1
        public Data search(int id)
        {
            Data ob = new Data();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Employee where EID =" + id;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        ob.EID = Convert.ToInt32(reader.GetValue(0));
                        ob.ENAME = reader.GetValue(1).ToString();
                        ob.DOB = Convert.ToDateTime(reader.GetValue(2));
                        ob.PHONE = Convert.ToInt64(reader.GetValue(3));
                        ob.EMAIL = reader.GetValue(4).ToString();
                        ob.SALARY = Convert.ToInt32(reader.GetValue(5));
                        ob.DEPTID = Convert.ToInt32(reader.GetValue(6));
                    }
                }
                else
                    ob = null;
            }
            catch (Exception)
            {
                MessageBox.Show("Couldnt connect to db");
            }
            finally
            {
                conn.Close();
            }

            return ob;
        }
        //data inserting using procedure in form1
        public string spinsert(Data st)
        {
            string str = null;
            SqlConnection conn = new SqlConnection(constr);
            string sql = "spinsert";
            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EID ", SqlDbType.Int).Value = st.EID;
                cmd.Parameters.Add("@ENAME", SqlDbType.VarChar, 50).Value = st.ENAME;
                cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = st.DOB;
                cmd.Parameters.Add("@PHONE", SqlDbType.BigInt).Value = st.PHONE;
                cmd.Parameters.Add("@EMAIL", SqlDbType.VarChar, 50).Value = st.EMAIL;
                cmd.Parameters.Add("@SALARY", SqlDbType.Int).Value = st.SALARY;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = st.DEPTID;
                cmd.ExecuteNonQuery();
                MessageBox.Show("data inserted successfully");
            }
            catch (Exception)
            {
                str = "Sorry couldnt insert ";
            }
            finally
            {
                conn.Close();
            }
            return str;
        }
        //data updating using procedure in form1
        public void updatedata(Data st)
        {
            SqlConnection conn = new SqlConnection(constr);
            string sql = "spUpdate";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EID ", SqlDbType.Int).Value = st.EID;
                cmd.Parameters.Add("@ENAME", SqlDbType.VarChar, 50).Value = st.ENAME;
                cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = st.DOB;
                cmd.Parameters.Add("@PHONE", SqlDbType.BigInt).Value = st.PHONE;
                cmd.Parameters.Add("@EMAIL", SqlDbType.VarChar, 50).Value = st.EMAIL;
                cmd.Parameters.Add("@SALARY", SqlDbType.Int).Value = st.SALARY;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = st.DEPTID;
                cmd.ExecuteNonQuery();
                MessageBox.Show("data updated  successfully");
            }
            catch (Exception)
            {
                MessageBox.Show("Sorry Coudent update ,Something went wrong!!! please check and try againg ");
            }
            finally
            {
                conn.Close();
            }

        }

        

        //data searcing on ename
        public Data Search(string na)
        {
            Data ob = new Data();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Employee where ENAME ='" + na + "'";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        ob.EID = Convert.ToInt32(reader.GetValue(0));
                        ob.ENAME = reader.GetValue(1).ToString();
                        ob.DOB = Convert.ToDateTime(reader.GetValue(2));
                        ob.PHONE = Convert.ToInt64(reader.GetValue(3));
                        ob.EMAIL = reader.GetValue(4).ToString();
                        ob.SALARY = Convert.ToInt32(reader.GetValue(5));
                        ob.DEPTID = Convert.ToInt32(reader.GetValue(6));
                    }
                }
                else
                    ob = null;
            }
            catch (Exception)
            {
                MessageBox.Show("Couldnt connect to db");
            }
            finally
            {
                conn.Close();
            }

            return ob;
        }
        ///data searcing on salary
        public Data SEARCH(int sal)
        {
            Data ob = new Data();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Employee where SALARY =" + sal;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        ob.EID = Convert.ToInt32(reader.GetValue(0));
                        ob.ENAME = reader.GetValue(1).ToString();
                        ob.DOB = Convert.ToDateTime(reader.GetValue(2));
                        ob.PHONE = Convert.ToInt64(reader.GetValue(3));
                        ob.EMAIL = reader.GetValue(4).ToString();
                        ob.SALARY = Convert.ToInt32(reader.GetValue(5));
                        ob.DEPTID = Convert.ToInt32(reader.GetValue(6));
                    }
                }
                else
                    ob = null;
            }
            catch (Exception)
            {
                MessageBox.Show("Couldnt connect to db");
            }
            finally
            {
                conn.Close();
            }

            return ob;
        }

        public DataTable getJoinTable()
        {
            DataTable td = new DataTable("quirey2");
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select e.ENAME,e.DOB,e.PHONE,e.EMAIL,e.SALARY,e.DEPTID,d.DNAME,d.DLOC FROM EMPLOYEE e,DEPATEMENT d WHERE d.MNGID = e.EID";
            try
            {
                
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(td);
                MessageBox.Show("quirey updated  successfully");
            }
            catch (Exception)
            {
                MessageBox.Show("Sorry Coudent update ,Something went wrong!!! please check and try againg ");
            }
            finally
            {
                conn.Close();
            }
            return td;
        }   //deleting row
            public string deleteSp(int i)
            {
                string msg = null;
                string sql = "spDelete";
                SqlConnection conn = new SqlConnection(constr);
                
                try
                {
                    conn.Open();

                    SqlCommand cmd = new SqlCommand(sql, conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@EID ", SqlDbType.Int).Value = i;
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("data inserted successfully");
                }
                catch (Exception)
                {
                    msg = "Sorry couldnt delete ";
                }
                finally
                {
                    conn.Close();
                }
                return msg;
            }
        
    }
}

    
