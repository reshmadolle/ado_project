﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Ado.Model
{
    class Data
    {
        private string v;

        public Data()
        {
        }

        public Data(string v)
        {
            this.v = v;
        }

        public int EID { get; set; }
        public string ENAME { get; set; }
        public DateTime DOB { get; set; }
        public Int64 PHONE { get; set; }
        public string EMAIL { get; set; }
        public int SALARY { get; set; }
        public int DEPTID { get; set; }

    }
    
}
