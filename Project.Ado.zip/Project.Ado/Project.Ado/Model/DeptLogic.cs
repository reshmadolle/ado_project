﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;

namespace Project.Ado.Model
{
    class DeptLogic
    {
        private string constr = ConfigurationManager.ConnectionStrings["db"].ConnectionString;
        public List<Dept> getDeptInfo()
        {
            List<Dept> li = new List<Dept>();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from depatement";
            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sql, conn);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Dept stu = new Dept();
                    stu.DEPTID = Convert.ToInt32(reader.GetValue(0));
                    stu.DNAME = reader.GetValue(1).ToString();
                    stu.DLOC = reader.GetValue(1).ToString();
                    stu.MNGID = Convert.ToInt32(reader.GetValue(3));
                    
                    li.Add(stu);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Connection failed......");
            }
            finally
            {
                conn.Close();
            }

            return li;
        }
        //searching with id in from1
        public Dept search(int id)
        {
            Dept ob = new Dept();
            SqlConnection conn = new SqlConnection(constr);
            string sql = "select * from Depatement where deptid =" + id;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        ob.DEPTID = Convert.ToInt32(reader.GetValue(0));
                        ob.DNAME = reader.GetValue(1).ToString();
                        ob.DLOC = reader.GetValue(1).ToString();
                        ob.MNGID = Convert.ToInt32(reader.GetValue(3));
                    }
                }
                else
                    ob = null;
            }
            catch (Exception)
            {
                MessageBox.Show("Couldnt connect to db");
            }
            finally
            {
                conn.Close();
            }

            return ob;
        }
        //data inserting using procedure in form1
        public string spinsert(Data st)
        {
            string str = null;
            SqlConnection conn = new SqlConnection(constr);
            string sql = "spinsert";
            try
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EID ", SqlDbType.Int).Value = st.EID;
                cmd.Parameters.Add("@ENAME", SqlDbType.VarChar, 50).Value = st.ENAME;
                cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = st.DOB;
                cmd.Parameters.Add("@PHONE", SqlDbType.BigInt).Value = st.PHONE;
                cmd.Parameters.Add("@EMAIL", SqlDbType.VarChar, 50).Value = st.EMAIL;
                cmd.Parameters.Add("@SALARY", SqlDbType.Int).Value = st.SALARY;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = st.DEPTID;
                cmd.ExecuteNonQuery();
                MessageBox.Show("data inserted successfully");
            }
            catch (Exception)
            {
                str = "Sorry couldnt insert ";
            }
            finally
            {
                conn.Close();
            }
            return str;
        }
        //data updating using procedure in form1
        public void updatedata(Data st)
        {
            SqlConnection conn = new SqlConnection(constr);
            string sql = "spUpdate";
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(sql, conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@EID ", SqlDbType.Int).Value = st.EID;
                cmd.Parameters.Add("@ENAME", SqlDbType.VarChar, 50).Value = st.ENAME;
                cmd.Parameters.Add("@DOB", SqlDbType.Date).Value = st.DOB;
                cmd.Parameters.Add("@PHONE", SqlDbType.BigInt).Value = st.PHONE;
                cmd.Parameters.Add("@EMAIL", SqlDbType.VarChar, 50).Value = st.EMAIL;
                cmd.Parameters.Add("@SALARY", SqlDbType.Int).Value = st.SALARY;
                cmd.Parameters.Add("@DEPTID", SqlDbType.Int).Value = st.DEPTID;
                cmd.ExecuteNonQuery();
                MessageBox.Show("data updated  successfully");
            }
            catch (Exception)
            {
                MessageBox.Show("Sorry Coudent update ,Something went wrong!!! please check and try againg ");
            }
            finally
            {
                conn.Close();
            }

        }
    }
}
