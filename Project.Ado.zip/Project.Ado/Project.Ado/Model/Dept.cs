﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Ado.Model
{
    class Dept
    {
        public int DEPTID { get; set; }
        public string DNAME { get; set; }
        public string DLOC { get; set; }
        public int MNGID { get; set; }
    }
}
