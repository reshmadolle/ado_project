﻿namespace Project.Ado
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tid = new System.Windows.Forms.TextBox();
            this.btnsearch = new System.Windows.Forms.Button();
            this.lid = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btninsert = new System.Windows.Forms.Button();
            this.btnupdate = new System.Windows.Forms.Button();
            this.lname = new System.Windows.Forms.Label();
            this.ldob = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lphone = new System.Windows.Forms.Label();
            this.lmail = new System.Windows.Forms.Label();
            this.lsalary = new System.Windows.Forms.Label();
            this.ldeptid = new System.Windows.Forms.Label();
            this.tname = new System.Windows.Forms.TextBox();
            this.tdob = new System.Windows.Forms.TextBox();
            this.tphone = new System.Windows.Forms.TextBox();
            this.tmail = new System.Windows.Forms.TextBox();
            this.tsalary = new System.Windows.Forms.TextBox();
            this.tdeptid = new System.Windows.Forms.TextBox();
            this.btndel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tid
            // 
            this.tid.Location = new System.Drawing.Point(249, 22);
            this.tid.Name = "tid";
            this.tid.Size = new System.Drawing.Size(100, 20);
            this.tid.TabIndex = 0;
            // 
            // btnsearch
            // 
            this.btnsearch.Location = new System.Drawing.Point(448, 22);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(75, 23);
            this.btnsearch.TabIndex = 1;
            this.btnsearch.Text = "SEARCH";
            this.btnsearch.UseVisualStyleBackColor = true;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // lid
            // 
            this.lid.AutoSize = true;
            this.lid.Location = new System.Drawing.Point(87, 22);
            this.lid.Name = "lid";
            this.lid.Size = new System.Drawing.Size(25, 13);
            this.lid.TabIndex = 2;
            this.lid.Text = "EID";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AccessibleRole = System.Windows.Forms.AccessibleRole.TitleBar;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(136, 326);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(396, 123);
            this.dataGridView1.TabIndex = 3;
            // 
            // btninsert
            // 
            this.btninsert.Location = new System.Drawing.Point(448, 94);
            this.btninsert.Name = "btninsert";
            this.btninsert.Size = new System.Drawing.Size(79, 28);
            this.btninsert.TabIndex = 4;
            this.btninsert.Text = "INSERT";
            this.btninsert.UseVisualStyleBackColor = true;
            this.btninsert.Click += new System.EventHandler(this.btninsert_Click);
            // 
            // btnupdate
            // 
            this.btnupdate.Location = new System.Drawing.Point(448, 154);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(79, 28);
            this.btnupdate.TabIndex = 5;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = true;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // lname
            // 
            this.lname.AutoSize = true;
            this.lname.Location = new System.Drawing.Point(87, 59);
            this.lname.Name = "lname";
            this.lname.Size = new System.Drawing.Size(45, 13);
            this.lname.TabIndex = 6;
            this.lname.Text = "ENAME";
            // 
            // ldob
            // 
            this.ldob.AutoSize = true;
            this.ldob.Location = new System.Drawing.Point(87, 94);
            this.ldob.Name = "ldob";
            this.ldob.Size = new System.Drawing.Size(30, 13);
            this.ldob.TabIndex = 7;
            this.ldob.Text = "DOB";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(87, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 13);
            this.label4.TabIndex = 8;
            // 
            // lphone
            // 
            this.lphone.AutoSize = true;
            this.lphone.Location = new System.Drawing.Point(87, 124);
            this.lphone.Name = "lphone";
            this.lphone.Size = new System.Drawing.Size(45, 13);
            this.lphone.TabIndex = 9;
            this.lphone.Text = "PHONE";
            // 
            // lmail
            // 
            this.lmail.AutoSize = true;
            this.lmail.Location = new System.Drawing.Point(87, 162);
            this.lmail.Name = "lmail";
            this.lmail.Size = new System.Drawing.Size(39, 13);
            this.lmail.TabIndex = 10;
            this.lmail.Text = "EMAIL";
            // 
            // lsalary
            // 
            this.lsalary.AutoSize = true;
            this.lsalary.Location = new System.Drawing.Point(87, 187);
            this.lsalary.Name = "lsalary";
            this.lsalary.Size = new System.Drawing.Size(49, 13);
            this.lsalary.TabIndex = 11;
            this.lsalary.Text = "SALARY";
            // 
            // ldeptid
            // 
            this.ldeptid.AutoSize = true;
            this.ldeptid.Location = new System.Drawing.Point(87, 220);
            this.ldeptid.Name = "ldeptid";
            this.ldeptid.Size = new System.Drawing.Size(47, 13);
            this.ldeptid.TabIndex = 12;
            this.ldeptid.Text = "DEPTID";
            // 
            // tname
            // 
            this.tname.Location = new System.Drawing.Point(249, 59);
            this.tname.Name = "tname";
            this.tname.Size = new System.Drawing.Size(100, 20);
            this.tname.TabIndex = 13;
            // 
            // tdob
            // 
            this.tdob.Location = new System.Drawing.Point(249, 94);
            this.tdob.Name = "tdob";
            this.tdob.Size = new System.Drawing.Size(100, 20);
            this.tdob.TabIndex = 14;
            // 
            // tphone
            // 
            this.tphone.Location = new System.Drawing.Point(249, 124);
            this.tphone.Name = "tphone";
            this.tphone.Size = new System.Drawing.Size(100, 20);
            this.tphone.TabIndex = 15;
            // 
            // tmail
            // 
            this.tmail.Location = new System.Drawing.Point(249, 155);
            this.tmail.Name = "tmail";
            this.tmail.Size = new System.Drawing.Size(100, 20);
            this.tmail.TabIndex = 16;
            // 
            // tsalary
            // 
            this.tsalary.Location = new System.Drawing.Point(249, 187);
            this.tsalary.Name = "tsalary";
            this.tsalary.Size = new System.Drawing.Size(100, 20);
            this.tsalary.TabIndex = 17;
            // 
            // tdeptid
            // 
            this.tdeptid.Location = new System.Drawing.Point(249, 220);
            this.tdeptid.Name = "tdeptid";
            this.tdeptid.Size = new System.Drawing.Size(100, 20);
            this.tdeptid.TabIndex = 18;
            // 
            // btndel
            // 
            this.btndel.Location = new System.Drawing.Point(448, 205);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(79, 28);
            this.btndel.TabIndex = 19;
            this.btndel.Text = "DELETE";
            this.btndel.UseVisualStyleBackColor = true;
            this.btndel.Click += new System.EventHandler(this.btndel_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btndel);
            this.Controls.Add(this.tdeptid);
            this.Controls.Add(this.tsalary);
            this.Controls.Add(this.tmail);
            this.Controls.Add(this.tphone);
            this.Controls.Add(this.tdob);
            this.Controls.Add(this.tname);
            this.Controls.Add(this.ldeptid);
            this.Controls.Add(this.lsalary);
            this.Controls.Add(this.lmail);
            this.Controls.Add(this.lphone);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.ldob);
            this.Controls.Add(this.lname);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.btninsert);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lid);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.tid);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tid;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Label lid;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btninsert;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Label lname;
        private System.Windows.Forms.Label ldob;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lphone;
        private System.Windows.Forms.Label lmail;
        private System.Windows.Forms.Label lsalary;
        private System.Windows.Forms.Label ldeptid;
        private System.Windows.Forms.TextBox tname;
        private System.Windows.Forms.TextBox tdob;
        private System.Windows.Forms.TextBox tphone;
        private System.Windows.Forms.TextBox tmail;
        private System.Windows.Forms.TextBox tsalary;
        private System.Windows.Forms.TextBox tdeptid;
        private System.Windows.Forms.Button btndel;
    }
}