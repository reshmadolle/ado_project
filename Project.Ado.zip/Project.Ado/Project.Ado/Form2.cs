﻿using Project.Ado.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.Ado
{
    public partial class Form2 : Form
    {
        DataLogic ob;
        public Form2()
        {
            InitializeComponent();
            ob = new DataLogic(); 
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            btndel.Visible = false;
            btninsert.Visible = false;
            btnupdate.Visible = false;
            tname.Visible = false;
            tdob.Visible = false;
            tphone.Visible = false;
            tmail.Visible = false;
            tsalary.Visible = false;
            tdeptid.Visible = false;
            lname.Visible = false;
            ldob.Visible = false;
            lphone.Visible = false;
            lmail.Visible = false;
            lsalary.Visible = false;
            ldeptid.Visible = false;
            dataGridView1.DataSource = ob.getAllData();
        }
        
        private void btnsearch_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32( tid.Text);
            Data d = ob.search(id);
            if (d==null)
            {
                MessageBox.Show("No Data is present");
            }
            else
            {
                List<Data> li = new List<Data>();
                li.Add(d);
                MessageBox.Show("Data is present");
                dataGridView1.Visible = true;
                btninsert.Visible = true;
                btndel.Visible = true;
                btnupdate.Visible = true;
                tid.Visible = true;
                tname.Visible = true;
                tdob.Visible = true;
                tphone.Visible = true;
                tmail.Visible = true;
                tsalary.Visible = true;
                tdeptid.Visible = true;
                lid.Visible = true;
                lname.Visible = true;
                ldob.Visible = true;
                lphone.Visible = true;
                lmail.Visible = true;
                lsalary.Visible = true;
                ldeptid.Visible = true;
                dataGridView1.DataSource = li;
            }
            tid.Text = " ";
        }

        private void btninsert_Click(object sender, EventArgs e)
        {

            Data st = new Data();
            st.EID = Convert.ToInt32(tid.Text);
            st.ENAME = tname.Text.ToString();
            st.DOB = Convert.ToDateTime(tdob.Text);
            st.PHONE = Convert.ToInt64(tphone.Text);
            st.EMAIL = tmail.Text.ToString();
            st.SALARY = Convert.ToInt32(tsalary.Text);
            st.DEPTID = Convert.ToInt32(tdeptid.Text);
            string str = ob.spinsert(st);
            MessageBox.Show(str);
            dataGridView1.DataSource = ob.getAllData();
            tid.Text = "";
            tname.Text = "";
            tdob.Text = "";
            tphone.Text = "";
            tmail.Text = "";
            tsalary.Text = "";
            tdeptid.Text = "";
            tname.Visible = false;
            tdob.Visible = false;
            tphone.Visible = false;
            tmail.Visible = false;
            tsalary.Visible = false;
            tdeptid.Visible = false;
            lname.Visible = false;
            ldob.Visible = false;
            lphone.Visible = false;
            lmail.Visible = false;
            lsalary.Visible = false;
            ldeptid.Visible = false;
            btninsert.Visible = false;
            btnupdate.Visible = false;
            btndel.Visible = false;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            Data st = new Data();
            st.EID = Convert.ToInt32(tid.Text);
            st.ENAME = tname.Text.ToString();
            st.DOB = Convert.ToDateTime(tdob.Text);
            st.PHONE = Convert.ToInt64(tphone.Text);
            st.EMAIL = tmail.Text.ToString();
            st.SALARY = Convert.ToInt32(tsalary.Text);
            st.DEPTID = Convert.ToInt32(tdeptid.Text);
            ob.updatedata(st);
            dataGridView1.DataSource = ob.getAllData();
            btninsert.Visible = false;
            btnupdate.Visible = false;
            tname.Visible = false;
            tdob.Visible = false;
            tphone.Visible = false;
            tmail.Visible = false;
            tsalary.Visible = false;
            tdeptid.Visible = false;
            lname.Visible = false;
            ldob.Visible = false;
            lphone.Visible = false;
            lmail.Visible = false;
            lsalary.Visible = false;
            ldeptid.Visible = false;
            btndel.Visible = false;
            tid.Text = "";
        }

        private void btndel_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(tid.Text);
            string msg = ob.search(id).ToString();
            MessageBox.Show(msg);
            tid.Text = "";
            dataGridView1.DataSource = ob.getAllData();
        }
    }
}
