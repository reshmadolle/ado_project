﻿using Project.Ado.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.Ado
{
    public partial class Form1 : Form
    {
        DataLogic ob;
        public Form1()
        {
            InitializeComponent();
            ob = new DataLogic();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ob.getAllData();
            dataGridView1.Visible = false;
            comboBox1.DataSource = ob.getAllData().Tables[0];
            comboBox1.DisplayMember = "name";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int index = comboBox1.SelectedIndex;
            index++;
            dataGridView1.DataSource = ob.getAllData().Tables[index];
            dataGridView1.Visible = true;
        }
    }
}
