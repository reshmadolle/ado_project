﻿using Project.Ado.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.Ado
{
    public partial class Form3 : Form
    {
        DeptLogic ob;
        public Form3()
        {
            InitializeComponent();
            ob = new DeptLogic();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView1.DataSource = ob.getDeptInfo();
            button2.Visible = false;
            button3.Visible = false;
            textBox2.Visible = false;
            textBox3.Visible = false;
            textBox4.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBox1.Text);
            Dept d = ob.search(id);
            if (d == null)
            {
                MessageBox.Show("No Data is present");
            }
            else
            {
                List<Dept> li = new List<Dept>();
                li.Add(d);
                MessageBox.Show("Data is present");
                dataGridView1.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                button1.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                dataGridView1.DataSource = li;
            }
            textBox1.Text = " ";
        }
    }
}
