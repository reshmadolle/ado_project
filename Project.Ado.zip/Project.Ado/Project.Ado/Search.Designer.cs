﻿namespace Project.Ado.Model
{
    partial class Search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ln = new System.Windows.Forms.Label();
            this.ls = new System.Windows.Forms.Label();
            this.tbn = new System.Windows.Forms.TextBox();
            this.tbs = new System.Windows.Forms.TextBox();
            this.btns = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnss = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // ln
            // 
            this.ln.AutoSize = true;
            this.ln.Location = new System.Drawing.Point(80, 48);
            this.ln.Name = "ln";
            this.ln.Size = new System.Drawing.Size(99, 13);
            this.ln.TabIndex = 0;
            this.ln.Text = "EMPLOYEE NAME";
            // 
            // ls
            // 
            this.ls.AutoSize = true;
            this.ls.Location = new System.Drawing.Point(578, 48);
            this.ls.Name = "ls";
            this.ls.Size = new System.Drawing.Size(49, 13);
            this.ls.TabIndex = 1;
            this.ls.Text = "SALARY";
            // 
            // tbn
            // 
            this.tbn.Location = new System.Drawing.Point(83, 102);
            this.tbn.Name = "tbn";
            this.tbn.Size = new System.Drawing.Size(100, 20);
            this.tbn.TabIndex = 2;
            // 
            // tbs
            // 
            this.tbs.Location = new System.Drawing.Point(581, 102);
            this.tbs.Name = "tbs";
            this.tbs.Size = new System.Drawing.Size(100, 20);
            this.tbs.TabIndex = 3;
            // 
            // btns
            // 
            this.btns.Location = new System.Drawing.Point(83, 170);
            this.btns.Name = "btns";
            this.btns.Size = new System.Drawing.Size(75, 23);
            this.btns.TabIndex = 4;
            this.btns.Text = "SEARCH";
            this.btns.UseVisualStyleBackColor = true;
            this.btns.Click += new System.EventHandler(this.btns_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(149, 284);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(443, 130);
            this.dataGridView1.TabIndex = 5;
            // 
            // btnss
            // 
            this.btnss.Location = new System.Drawing.Point(581, 170);
            this.btnss.Name = "btnss";
            this.btnss.Size = new System.Drawing.Size(75, 23);
            this.btnss.TabIndex = 6;
            this.btnss.Text = "SEARCH";
            this.btnss.UseVisualStyleBackColor = true;
            this.btnss.Click += new System.EventHandler(this.btnss_Click);
            // 
            // Search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnss);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btns);
            this.Controls.Add(this.tbs);
            this.Controls.Add(this.tbn);
            this.Controls.Add(this.ls);
            this.Controls.Add(this.ln);
            this.Name = "Search";
            this.Text = "Search";
            this.Load += new System.EventHandler(this.Search_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ln;
        private System.Windows.Forms.Label ls;
        private System.Windows.Forms.TextBox tbn;
        private System.Windows.Forms.TextBox tbs;
        private System.Windows.Forms.Button btns;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnss;
    }
}