﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project.Ado.Model
{
    public partial class Search : Form
    {
        DataLogic ob;
        public Search()
        {
            InitializeComponent();
            ob = new DataLogic();
        }

        private void Search_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
            dataGridView1.DataSource = ob.getAllData();
        }

        private void btns_Click(object sender, EventArgs e)
        {
            string na = tbn.Text.ToString();
            Data d = ob.Search(na);
            if (d == null)
            {
                MessageBox.Show("No Data is present");
            }
            else
            {
                List<Data> li = new List<Data>();
                li.Add(d);
                MessageBox.Show("Data is present");
                dataGridView1.Visible = true;

                dataGridView1.DataSource = li;
            }
            tbn.Text = " ";
        }

        private void btnss_Click(object sender, EventArgs e)
        {
            int sal = Convert.ToInt32( tbs.Text);
            Data d = ob.SEARCH(sal);
            if (d == null)
            {
                MessageBox.Show("No Data is present");
            }
            else
            {
                List<Data> li = new List<Data>();
                li.Add(d);
                MessageBox.Show("Data is present");
                dataGridView1.Visible = true;

                dataGridView1.DataSource = li;
            }
            tbn.Text = " ";
        }
    }
}
